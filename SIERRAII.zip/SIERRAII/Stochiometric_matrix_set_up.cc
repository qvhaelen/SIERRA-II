#include<cmath>
#include<iomanip>
#include"Stochiometric_matrix_set_up.h"
void Stochiometric_matrix_set_up(int** stochio_matrix){

stochio_matrix[1][18] = -1;
stochio_matrix[1][22] = -1;
stochio_matrix[1][25] = 1;
stochio_matrix[1][29] = 1;
stochio_matrix[2][1] = 1;
stochio_matrix[2][9] = -1;
stochio_matrix[2][18] = 1;
stochio_matrix[2][28] = -1;
stochio_matrix[2][29] = -1;
stochio_matrix[3][1] = 1;
stochio_matrix[3][9] = -1;
stochio_matrix[3][23] = -1;
stochio_matrix[3][26] = 1;
stochio_matrix[4][1] = -1;
stochio_matrix[4][2] = -1;
stochio_matrix[4][9] = 1;
stochio_matrix[4][13] = 1;
stochio_matrix[5][2] = 1;
stochio_matrix[5][4] = 1;
stochio_matrix[5][5] = 1;
stochio_matrix[5][6] = 1;
stochio_matrix[5][12] = -1;
stochio_matrix[5][13] = -1;
stochio_matrix[5][14] = -1;
stochio_matrix[5][15] = -1;
stochio_matrix[6][3] = -1;
stochio_matrix[6][4] = -1;
stochio_matrix[6][5] = -1;
stochio_matrix[6][14] = 1;
stochio_matrix[7][6] = -1;
stochio_matrix[7][10] = -1;
stochio_matrix[7][11] = -1;
stochio_matrix[7][15] = 1;
stochio_matrix[8][4] = 1;
stochio_matrix[8][14] = -1;
stochio_matrix[8][21] = -1;
stochio_matrix[8][32] = -1;
stochio_matrix[8][33] = 1;
stochio_matrix[9][5] = 1;
stochio_matrix[9][7] = 1;
stochio_matrix[9][16] = -1;
stochio_matrix[9][21] = 1;
stochio_matrix[9][34] = -1;
stochio_matrix[9][35] = 1;
stochio_matrix[10][7] = -1;
stochio_matrix[10][16] = 1;
stochio_matrix[11][8] = 1;
stochio_matrix[11][17] = -1;
stochio_matrix[11][20] = -1;
stochio_matrix[11][34] = 1;
stochio_matrix[11][35] = -1;
stochio_matrix[12][20] = 1;
stochio_matrix[12][32] = 1;
stochio_matrix[12][33] = -1;
stochio_matrix[13][8] = -1;
stochio_matrix[13][17] = 1;
stochio_matrix[14][30] = 1;
stochio_matrix[14][36] = -1;
stochio_matrix[15][19] = -1;
stochio_matrix[15][36] = 1;
stochio_matrix[16][6] = 1;
stochio_matrix[16][15] = -1;
stochio_matrix[16][27] = -1;
stochio_matrix[16][31] = 1;
stochio_matrix[17][7] = 1;
stochio_matrix[17][16] = -1;
stochio_matrix[18][8] = 1;
stochio_matrix[18][17] = -1;
stochio_matrix[19][11] = 1;
stochio_matrix[19][24] = -1;
stochio_matrix[20][18] = -1;
return;}



















































