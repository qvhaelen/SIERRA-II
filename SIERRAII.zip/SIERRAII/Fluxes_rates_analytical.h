void Fluxes_rates_analytical(double** DvDx_matrix, double* X, double* k);
