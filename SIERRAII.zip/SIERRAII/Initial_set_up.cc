#include "Initial_set_up.h"
void Initial_set_up(int& number_vertices,int& nbre_colonne,int& number_time_points, int& nbre_reactions, int& nbre_kinetic_cte){
number_vertices =20;
nbre_colonne =21;
number_time_points = 5000;
nbre_reactions =36;
nbre_kinetic_cte = 36;
return;}




