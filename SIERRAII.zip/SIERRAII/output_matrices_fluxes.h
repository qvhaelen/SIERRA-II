void output_matrices_fluxes(double** matrix_GAMMA,  double**matrix_C, int& nbre_reactions,int& number_vertices, int& time_point,int* X_echelon_label);
