void Gauss_Jordan_pivoting(int* X_echelon_label, int** stochio_matrix, double** stochio_matrix_echelon, int& number_vertices, int& nbre_reactions);
