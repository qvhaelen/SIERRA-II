void Fluxes_rates_analytical_init(double** DvDx_matrix, double* X, double* k);
