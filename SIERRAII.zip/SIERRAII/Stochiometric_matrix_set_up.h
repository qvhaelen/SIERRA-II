void Stochiometric_matrix_set_up(int** stochio_matrix);
