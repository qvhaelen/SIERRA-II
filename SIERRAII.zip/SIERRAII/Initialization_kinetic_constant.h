void  Initialization_kinetic_constant( double* k);
