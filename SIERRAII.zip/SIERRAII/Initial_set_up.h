void Initial_set_up(int& number_vertices,int& nbre_colonne,int& number_time_points, int& nbre_reactions, int& nbre_kinetic_cte);
